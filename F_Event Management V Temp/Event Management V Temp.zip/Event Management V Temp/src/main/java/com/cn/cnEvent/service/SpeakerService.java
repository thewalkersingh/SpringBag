package com.cn.cnEvent.service;
import com.cn.cnEvent.dal.EventDAL;
import com.cn.cnEvent.dal.SpeakerDAL;
import com.cn.cnEvent.entity.Event;
import com.cn.cnEvent.entity.Speaker;
import com.cn.cnEvent.exception.InvalidInputException;
import com.cn.cnEvent.exception.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class SpeakerService {
	@Autowired
	SpeakerDAL speakerDAL;
	@Autowired
	EventDAL eventDAL;
	
	@Transactional
	public Speaker getSpeakerById(Long id) {
		Speaker speaker = speakerDAL.getSpeakerById(id);
		if (speaker == null) throw new NotFoundException("No speaker found with this id");
		return speaker;
	}
	
	@Transactional
	public void saveSpeakerEvent(Long eventId, Long speakerId) {
		Speaker speaker = getSpeakerById(speakerId);
		Event event = eventDAL.getById(eventId);
		if (speaker == null) {
			throw new NotFoundException("Speaker not found.");
		}
		if (event == null) {
			throw new NotFoundException("Event not found.");
		}
		speaker.getEvents().add(event);
		event.getSpeakers().add(speaker);
		try {
			speakerDAL.saveSpeaker(speaker);
		} catch (Exception e) {
			throw new InvalidInputException("Some error occurred: " + e.getMessage());
		}
	}
	
	@Transactional
	public String saveSpeaker(Speaker speaker) {
		if (speaker == null) {
			throw new InvalidInputException("Invalid speaker data");
		}
		if (speaker.getId() == null) {
			speakerDAL.saveSpeaker(speaker);
		}
		return "The speaker saved successfully";
	}
	
	@Transactional
	public List<Speaker> getAllSpeaker() {
		List<Speaker> speakersList = speakerDAL.getAllSpeakers();
		if (speakersList.isEmpty()) throw new NotFoundException("No List of speakers found");
		return speakersList;
	}
	
	//	@Transactional
//	public List<Speaker> getSpeakerByEventAndExperience(Long eventCount, Long experience) {
//		List<Speaker> eligibleSpeakers = new ArrayList<>();
//		List<Speaker> allSpeakers = speakerDAL.getAllSpeakers();
//		for (Speaker speaker : allSpeakers) {
//			if (speaker.getEvents().size() >= eventCount && speaker.getExperience() >= experience) {
//				eligibleSpeakers.add(speaker);
//			}
//		}
//		return eligibleSpeakers;
//	}
	@Transactional
	public List<Speaker> getSpeakerByEventAndExperience(Long eventCount, Long experience) {
		return speakerDAL.getSpeakerByEventAndExperience(eventCount, experience);
	}
}